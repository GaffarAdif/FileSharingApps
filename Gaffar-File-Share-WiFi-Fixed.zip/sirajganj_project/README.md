# Gaffar-File-Share

Offline/local Android file sharing using a receiver-created local Wi-Fi hotspot.

## Flow
1. Receiver taps Receiver and grants Nearby Wi-Fi/Location permissions if Android asks.
2. The app starts an Android LocalOnlyHotspot and displays a QR containing the hotspot SSID/password and receiver address.
3. Sender taps Sender and grants Nearby Wi-Fi/Location permission.
4. Sender scans the receiver QR and approves Android's Wi-Fi connection prompt.
5. Sender selects one or more files. Files are sent over the local Wi-Fi connection; internet is not required.

## Important Android behavior
Android does not expose a normal runtime permission called "Hotspot permission". Starting a LocalOnlyHotspot can require Nearby Wi-Fi/Location permissions and Android may show system-controlled Wi-Fi prompts. The app cannot silently bypass those system prompts.

## Build
Use the included GitHub Actions workflow or place the project in a repository and run the workflow manually.
