# Gaffar-File-Share

Offline/local Android file sharing between two Android phones.

## How it works

1. On the **Receiver** phone, open the app and tap **Receiver**.
2. Android grants the required Nearby Wi-Fi permission and the app starts a **LocalOnlyHotspot**.
3. The receiver displays a QR containing the hotspot SSID, password, receiver IPv4 address and transfer port.
4. On the **Sender** phone, tap **Sender** → **Open Camera to Scan**.
5. Scan the receiver QR and approve Android's Wi-Fi connection prompt if shown.
6. After the phones connect, select one or more files.
7. Files are sent directly over the local Wi-Fi network. Internet access is not required.
8. Received files are saved under **Download/Sirajganj Polytechnic File Share** on Android 10+.

## QR format

The current QR format is `GFS2|<Base64>`. It contains:

`SSID + newline + password + newline + receiver IPv4 + newline + port`

The app still accepts the older `GFS1`/`SFSWIFI` formats for compatibility.

## Important Android behavior

- The app cannot bypass Android's system Wi-Fi connection approval dialog.
- LocalOnlyHotspot is controlled by Android/OEM firmware, so some phones may restrict or stop a local hotspot.
- The receiver must keep the app open while files are being received.
- Android 13+ uses the Nearby Wi-Fi Devices permission; older Android versions may require Location permission.

## Build with GitHub Actions

Push the project to a GitHub repository, then open:

**Actions → Build Gaffar-File-Share APK → Run workflow**

The generated APK is uploaded as an artifact named **Gaffar-File-Share-debug**.
