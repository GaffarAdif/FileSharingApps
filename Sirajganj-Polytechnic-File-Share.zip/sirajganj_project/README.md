# Sirajganj Polytechnic File Share

Offline/local Android file sharing app for a college project. UI follows the supplied reference screenshots.

## How the connection works
This version uses a local Wi-Fi network (for example, one phone's hotspot with the other phone connected to it). The Receiver starts a tiny HTTP server and shows its local IP/port as a QR code. The Sender scans the QR, selects files, and uploads them directly to the Receiver. No Internet is needed for the transfer.

> Android hotspot/Wi-Fi behavior differs by device. If the receiver cannot determine an IPv4 address, connect both phones to the same Wi-Fi/hotspot and try again.

## GitHub APK build
1. Create a GitHub repository.
2. Upload the contents of this ZIP (not the ZIP itself).
3. Push to `main` or `master`.
4. Open **Actions** → **Build APK** and wait for the workflow.
5. Open the completed workflow run → **Artifacts** → download the APK.

The project intentionally has no server or database dependency.
