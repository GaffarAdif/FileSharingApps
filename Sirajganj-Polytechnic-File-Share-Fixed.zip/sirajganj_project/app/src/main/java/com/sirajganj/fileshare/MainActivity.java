package com.sirajganj.fileshare;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.camera.core.*;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.common.InputImage;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends androidx.activity.ComponentActivity {
    static final int BLUE=Color.rgb(24,132,245), GREEN=Color.rgb(52,199,89), DARK=Color.rgb(20,20,22), GRAY=Color.rgb(105,105,110);
    static final int PICK_FILES=10, CAMERA_REQ=11, PORT=8988;
    LinearLayout root; TextView title; ServerThread server; boolean receiverMode=false; PreviewView previewView;
    ArrayList<Uri> selectedUris=new ArrayList<>();

    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    TextView tv(String text,float sp,int color){ TextView t=new TextView(this); t.setText(text); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.CENTER); return t; }
    GradientDrawable round(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g; }
    TextView button(String text,int color){ TextView b=tv(text,18,Color.WHITE); b.setTypeface(null,1); b.setBackground(round(color,32)); b.setPadding(dp(12),dp(14),dp(12),dp(14)); b.setClickable(true); return b; }
    TextView backButton(){ TextView b=tv("‹",48,DARK); b.setGravity(Gravity.CENTER); b.setOnClickListener(v->home()); return b; }
    void base(boolean withHeader,String header){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.WHITE);
        root.setPadding(dp(18),dp(10),dp(18),dp(18)); setContentView(root);
        if(withHeader){ LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(0,0,0,dp(8));
            TextView back=backButton(); bar.addView(back,new LinearLayout.LayoutParams(dp(62),dp(62)));
            title=tv(header,32,DARK); title.setTypeface(null,1); title.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT); bar.addView(title,new LinearLayout.LayoutParams(0,dp(62),1));
            root.addView(bar); View line=new View(this); line.setBackgroundColor(0xFFE5E5E7); root.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        }
    }
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.WHITE); getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); home();}

    void home(){
        if(server!=null){server.stopServer();server=null;} receiverMode=false;
        base(false,"");
        Space top=new Space(this); root.addView(top,new LinearLayout.LayoutParams(1,dp(70)));
        TextView logo=tv("➤",86,BLUE); logo.setTypeface(null,1); root.addView(logo,new LinearLayout.LayoutParams(-1,dp(105)));
        TextView name=tv("Sirajganj Polytechnic File Share",34,DARK); name.setTypeface(null,1); root.addView(name,new LinearLayout.LayoutParams(-1,dp(65)));
        TextView sub=tv("Choose your role",20,GRAY); root.addView(sub,new LinearLayout.LayoutParams(-1,dp(45)));
        Space gap=new Space(this); root.addView(gap,new LinearLayout.LayoutParams(1,dp(18)));
        LinearLayout sender=card(); TextView si=tv("↑",58,BLUE); sender.addView(si,new LinearLayout.LayoutParams(-1,dp(75))); TextView st=tv("Sender",26,DARK); st.setTypeface(null,1); sender.addView(st,new LinearLayout.LayoutParams(-1,dp(42))); sender.addView(tv("I want to send files",19,GRAY),new LinearLayout.LayoutParams(-1,dp(42))); sender.setOnClickListener(v->senderScan()); root.addView(sender,new LinearLayout.LayoutParams(-1,dp(250)));
        Space g2=new Space(this); root.addView(g2,new LinearLayout.LayoutParams(1,dp(22)));
        LinearLayout rec=card(); TextView ri=tv("↓",58,GREEN); rec.addView(ri,new LinearLayout.LayoutParams(-1,dp(75))); TextView rt=tv("Receiver",26,DARK); rt.setTypeface(null,1); rec.addView(rt,new LinearLayout.LayoutParams(-1,dp(42))); rec.addView(tv("I want to receive files",19,GRAY),new LinearLayout.LayoutParams(-1,dp(42))); rec.setOnClickListener(v->receiver()); root.addView(rec,new LinearLayout.LayoutParams(-1,dp(250)));
    }
    LinearLayout card(){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER); c.setPadding(dp(12),dp(15),dp(12),dp(10)); c.setBackground(round(Color.WHITE,28)); c.setElevation(dp(7)); return c; }

    void senderScan(){
        base(true,"Sender");
        Space s=new Space(this); root.addView(s,new LinearLayout.LayoutParams(1,dp(80)));
        LinearLayout box=card(); TextView icon=tv("▣",92,BLUE); box.addView(icon,new LinearLayout.LayoutParams(-1,dp(210))); TextView cap=tv("Scan Receiver's QR Code",24,DARK); cap.setTypeface(null,1); box.addView(cap,new LinearLayout.LayoutParams(-1,dp(55))); root.addView(box,new LinearLayout.LayoutParams(-1,dp(430)));
        Space sp=new Space(this); root.addView(sp,new LinearLayout.LayoutParams(1,dp(18)));
        TextView open=button("Open Camera to Scan",BLUE); open.setOnClickListener(v->startScanner()); root.addView(open,new LinearLayout.LayoutParams(-1,dp(62)));
        root.addView(tv("Make sure the receiver is ready",17,GRAY),new LinearLayout.LayoutParams(-1,dp(60)));
    }
    void startScanner(){
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},CAMERA_REQ);return;}
        FrameLayout frame=new FrameLayout(this); frame.setBackgroundColor(Color.BLACK); setContentView(frame); previewView=new PreviewView(this); frame.addView(previewView,new FrameLayout.LayoutParams(-1,-1));
        TextView close=tv("×",44,Color.WHITE); close.setOnClickListener(v->senderScan()); FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(60),dp(60),Gravity.TOP|Gravity.START); cp.setMargins(dp(15),dp(20),0,0); frame.addView(close,cp);
        TextView hint=tv("Point camera at Receiver QR",19,Color.WHITE); hint.setBackground(round(0x88000000,20)); FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-2,dp(55),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL); hp.setMargins(dp(20),0,dp(20),dp(45)); frame.addView(hint,hp);
        ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this); future.addListener(()->{try{ProcessCameraProvider p=future.get(); Preview pre=new Preview.Builder().build(); pre.setSurfaceProvider(previewView.getSurfaceProvider()); ImageAnalysis an=new ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build(); BarcodeScanner scanner=BarcodeScanning.getClient(); an.setAnalyzer(Executors.newSingleThreadExecutor(),image->{ImageProxy ip=image; android.media.Image media=ip.getImage(); if(media!=null){InputImage ii=InputImage.fromMediaImage(media,ip.getImageInfo().getRotationDegrees()); scanner.process(ii).addOnSuccessListener(codes->{for(com.google.mlkit.vision.barcode.common.Barcode c:codes){String raw=c.getRawValue(); if(raw!=null&&raw.startsWith("SFS|")){runOnUiThread(()->{try{p.unbindAll();scanner.close();connectToReceiver(raw);}catch(Exception e){toast("Invalid QR code");}});break;}}}).addOnCompleteListener(x->ip.close());}else ip.close();}); p.unbindAll(); p.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,pre,an);}catch(Exception e){toast("Camera could not start");}},ContextCompat.getMainExecutor(this));
    }
    void connectToReceiver(String raw){String[] a=raw.split("\\|"); if(a.length<3){toast("Invalid receiver QR");senderScan();return;} String host=a[1]; int port; try{port=Integer.parseInt(a[2]);}catch(Exception e){toast("Invalid receiver port");senderScan();return;} senderConnected(host,port);}

    void senderConnected(String host,int port){
        base(true,"Sender"); Space s=new Space(this);root.addView(s,new LinearLayout.LayoutParams(1,dp(35)));
        TextView ok=tv("✓",74,GREEN); ok.setTypeface(null,1); root.addView(ok,new LinearLayout.LayoutParams(-1,dp(100))); TextView con=tv("Connected successfully",24,GREEN);con.setTypeface(null,1);root.addView(con,new LinearLayout.LayoutParams(-1,dp(55)));
        LinearLayout box=card(); TextView folder=tv("▰",78,BLUE);box.addView(folder,new LinearLayout.LayoutParams(-1,dp(100)));TextView ct=tv("Choose File",40,BLUE);ct.setTypeface(null,1);box.addView(ct,new LinearLayout.LayoutParams(-1,dp(65)));TextView pick=button("Select Files",BLUE);pick.setOnClickListener(v->pickFiles(host,port));box.addView(pick,new LinearLayout.LayoutParams(-1,dp(65)));box.addView(tv("You can select multiple files",17,GRAY),new LinearLayout.LayoutParams(-1,dp(55)));root.addView(box,new LinearLayout.LayoutParams(-1,dp(400)));
    }
    void pickFiles(String host,int port){selectedUris.clear();Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);pendingHost=host;pendingPort=port;startActivityForResult(i,PICK_FILES);}
    String pendingHost;int pendingPort;
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==PICK_FILES&&res==RESULT_OK&&data!=null){if(data.getClipData()!=null){for(int j=0;j<data.getClipData().getItemCount();j++)selectedUris.add(data.getClipData().getItemAt(j).getUri());}else if(data.getData()!=null)selectedUris.add(data.getData());if(!selectedUris.isEmpty())sendFiles(pendingHost,pendingPort);}}

    void sendFiles(String host,int port){
        base(true,"Sending..."); Space s=new Space(this);root.addView(s,new LinearLayout.LayoutParams(1,dp(65)));
        TextView pct=tv("0%",68,BLUE);pct.setTypeface(null,1);root.addView(pct,new LinearLayout.LayoutParams(-1,dp(145))); ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(0);bar.setProgressDrawable(roundProgress(BLUE,0xFFE5E5E8));root.addView(bar,new LinearLayout.LayoutParams(-1,dp(22)));TextView status=tv("Sending files...",22,DARK);root.addView(status,new LinearLayout.LayoutParams(-1,dp(65)));TextView file=tv("",18,GRAY);root.addView(file,new LinearLayout.LayoutParams(-1,dp(55)));TextView cancel=tv("Cancel",22,GRAY);cancel.setBackground(round(Color.WHITE,22));cancel.setElevation(dp(3));root.addView(cancel,new LinearLayout.LayoutParams(-1,dp(70)));final boolean[] cancelled={false};cancel.setOnClickListener(v->cancelled[0]=true);
        new Thread(()->{long total=0,done=0;for(Uri u:selectedUris){long z=sizeOf(u);if(z>0)total+=z;}if(total<=0)total=selectedUris.size();for(Uri u:selectedUris){if(cancelled[0])break;String n=nameOf(u);runOnUiThread(()->file.setText(n));try{long z=sendOne(host,port,u);done+=Math.max(z,1);int p=(int)Math.min(100,done*100/total);runOnUiThread(()->{pct.setText(p+"%");bar.setProgress(p);});}catch(Exception e){runOnUiThread(()->toast("Transfer failed: "+e.getMessage()));break;}}runOnUiThread(()->{if(cancelled[0])status.setText("Transfer cancelled");else {status.setText("Transfer complete");pct.setText("100%");bar.setProgress(100);}});}).start();
    }
    GradientDrawable roundProgress(int fg,int bg){GradientDrawable g=new GradientDrawable();g.setColor(bg);g.setCornerRadius(dp(15));return g;}
    long sendOne(String host,int port,Uri uri)throws Exception{String name=nameOf(uri);long len=sizeOf(uri);if(len<0)throw new IOException("Unknown file size");HttpURLConnection c=(HttpURLConnection)new URL("http://"+host+":"+port+"/upload").openConnection();c.setDoOutput(true);c.setRequestMethod("POST");c.setConnectTimeout(8000);c.setReadTimeout(120000);c.setFixedLengthStreamingMode(len);c.setRequestProperty("Content-Length",String.valueOf(len));c.setRequestProperty("X-Filename",URLEncoder.encode(name,"UTF-8"));try(OutputStream out=c.getOutputStream();InputStream in=getContentResolver().openInputStream(uri)){byte[] buf=new byte[64*1024];int r;while((r=in.read(buf))!=-1)out.write(buf,0,r);}int code=c.getResponseCode();if(code!=200)throw new IOException("Receiver error "+code);c.disconnect();return len;}
    String nameOf(Uri u){Cursor c=getContentResolver().query(u,null,null,null,null);if(c!=null){try{int i=c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME);if(c.moveToFirst()&&i>=0)return c.getString(i);}finally{c.close();}}return "file";}
    long sizeOf(Uri u){Cursor c=getContentResolver().query(u,null,null,null,null);if(c!=null){try{int i=c.getColumnIndex(MediaStore.MediaColumns.SIZE);if(c.moveToFirst()&&i>=0)return c.getLong(i);}finally{c.close();}}return -1;}

    void receiver(){receiverMode=true;base(true,"Receiver");try{server=new ServerThread();}catch(Exception e){toast("Could not start receiver");return;}TextView label=tv("Show this QR to Sender",24,GRAY);root.addView(label,new LinearLayout.LayoutParams(-1,dp(65)));ImageView qr=new ImageView(this);qr.setPadding(dp(18),dp(18),dp(18),dp(18));root.addView(qr,new LinearLayout.LayoutParams(-1,dp(380)));TextView wait=tv("Waiting for connection...",20,GRAY);root.addView(wait,new LinearLayout.LayoutParams(-1,dp(65)));TextView addr=tv("Starting local connection...",15,GRAY);root.addView(addr,new LinearLayout.LayoutParams(-1,dp(55)));server.setCallback(new ServerCallback(){public void ready(String ip){runOnUiThread(()->{try{qr.setImageBitmap(makeQr("SFS|"+ip+"|"+PORT));addr.setText(ip+":"+PORT);wait.setText("Waiting for connection...");}catch(Exception e){addr.setText("QR generation failed");}});}public void connected(){runOnUiThread(()->wait.setText("Connected with Sender"));}public void received(String name){runOnUiThread(()->wait.setText("Received: "+name));}public void error(String e){runOnUiThread(()->toast(e));}});server.start();}
    Bitmap makeQr(String text)throws Exception{BitMatrix m=new MultiFormatWriter().encode(text,BarcodeFormat.QR_CODE,dp(260),dp(260));Bitmap b=Bitmap.createBitmap(m.getWidth(),m.getHeight(),Bitmap.Config.ARGB_8888);for(int x=0;x<m.getWidth();x++)for(int y=0;y<m.getHeight();y++)b.setPixel(x,y,m.get(x,y)?Color.BLACK:Color.WHITE);return b;}

    interface ServerCallback{void ready(String ip);void connected();void received(String name);void error(String e);}
    class ServerThread extends Thread{ServerSocket ss;volatile boolean run=true;ServerCallback cb;
        void setCallback(ServerCallback c){cb=c;if(ss!=null){} }
        void stopServer(){run=false;try{if(ss!=null)ss.close();}catch(Exception ignored){}}
        public void run(){try{ss=new ServerSocket(PORT);String ip=findIp();if(cb!=null)cb.ready(ip);while(run){Socket s=ss.accept();if(cb!=null)cb.connected();new Thread(()->handle(s)).start();}}catch(Exception e){if(run&&cb!=null)cb.error("Receiver stopped: "+e.getMessage());}}
        String findIp(){try{Enumeration<NetworkInterface> ns=NetworkInterface.getNetworkInterfaces();while(ns.hasMoreElements()){NetworkInterface n=ns.nextElement();Enumeration<InetAddress> as=n.getInetAddresses();while(as.hasMoreElements()){InetAddress a=as.nextElement();if(!a.isLoopbackAddress()&&a instanceof Inet4Address)return a.getHostAddress();}}}catch(Exception ignored){}return "127.0.0.1";}
        void handle(Socket s){try{InputStream in=new BufferedInputStream(s.getInputStream());ByteArrayOutputStream head=new ByteArrayOutputStream();int prev=0,cur;while((cur=in.read())!=-1){head.write(cur);if(prev=='\r'&&cur=='\n'){byte[] h=head.toByteArray();int n=h.length;if(n>=4&&h[n-4]=='\r'&&h[n-3]=='\n'&&h[n-2]=='\r'&&h[n-1]=='\n')break;}prev=cur;}String hs=head.toString(StandardCharsets.ISO_8859_1.name());long len=parseLongHeader(hs,"Content-Length");String fn=decodeHeader(hs,"X-Filename");if(len<0)throw new IOException("Missing file size");saveIncoming(in,len,fn);OutputStream out=s.getOutputStream();out.write("HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK".getBytes(StandardCharsets.ISO_8859_1));out.flush();if(cb!=null)cb.received(fn);}catch(Exception e){if(cb!=null)cb.error("Receive error: "+e.getMessage());}finally{try{s.close();}catch(Exception ignored){}}}
        long parseLongHeader(String h,String key){for(String l:h.split("\\r\\n")){if(l.toLowerCase(Locale.US).startsWith(key.toLowerCase(Locale.US)+":")){try{return Long.parseLong(l.substring(l.indexOf(':')+1).trim());}catch(Exception ignored){}}}return -1;}
        String decodeHeader(String h,String key){for(String l:h.split("\\r\\n")){if(l.toLowerCase(Locale.US).startsWith(key.toLowerCase(Locale.US)+":")){try{return URLDecoder.decode(l.substring(l.indexOf(':')+1).trim(),"UTF-8");}catch(Exception ignored){}}}return "received_file";}
        void saveIncoming(InputStream in,long len,String fn)throws Exception{fn=fn.replaceAll("[^a-zA-Z0-9._ -]","_");OutputStream out;Uri uri=null;if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,fn);v.put(MediaStore.Downloads.MIME_TYPE,"application/octet-stream");v.put(MediaStore.Downloads.RELATIVE_PATH,"Download/Sirajganj Polytechnic File Share");uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(uri==null)throw new IOException("Cannot create download");out=getContentResolver().openOutputStream(uri);}else{File d=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"Sirajganj Polytechnic File Share");if(!d.exists())d.mkdirs();out=new FileOutputStream(new File(d,fn));}try(OutputStream o=out){byte[] b=new byte[64*1024];long left=len;while(left>0){int r=in.read(b,0,(int)Math.min(b.length,left));if(r<0)throw new EOFException();o.write(b,0,r);left-=r;}}}
    }
    @Override public void onRequestPermissionsResult(int r,@NonNull String[] p,@NonNull int[] g){super.onRequestPermissionsResult(r,p,g);if(r==CAMERA_REQ&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startScanner();else if(r==CAMERA_REQ)toast("Camera permission is required to scan QR");}
    void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
    @Override protected void onDestroy(){if(server!=null)server.stopServer();super.onDestroy();}
}
